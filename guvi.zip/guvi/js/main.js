var pageUtil = {
	Ajaxcall : function(action, dataParam,requestType,CallBackFunction,Sync){
		var synTF = sync = true?false:true;
		$.ajax({
			"url" : action,
			"data" : dataParam,
			"type" : requestType,
			"asyn" : synTF,
			"success" : function(respJson){
				CallBackFunction(respJson);
			},
			"error" : function(http){
				alert("Error while processing your request")
			}
		});
	},
	registeruser : function(){
		var name = $('#reg_user_name').val();
		var pass = $('#reg_user_pass').val();
		var cnfpass = $('#reg_user_cnfpass').val();
		var dob = $('#reg_user_dob').val();
		var phone = $('#reg_user_phone').val();
		var action = "handle_ajax_call.php";
		var params = {};
		params.name = name;
		params.pass = pass;
		params.cnfpass = cnfpass;
		params.dob = dob;
		params.phone = phone;
		params.action = "registerUser";
		var requestType = "POST";
		var CallBackFunction = function(data){
			if(data !== undefined)
			{
				
				var jsonobj = $.parseJSON(data);
				if(jsonobj.resultId == 3)
				{
					var name = jsonobj.name
					window.location.replace("profile_page.php");
					
				}
				else if(jsonobj.resultId == 2){
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.result+'</p>');
	
				}
				else if(jsonobj.resultId == 1)
				{
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.result+'</p>');
	
				}
				else if(jsonobj.resultId == 6){
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.password+'</p>');
	
				}
				else if(jsonobj.resultId == 7){
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.phone+'</p>');
	
				}
			}

		}
		//if(!projectorUtil.validateEmail(staff_mail))
		//{
			//projectorUtil.showErrorOrSuccessMsg("Invalid email address", false);
			//return false;
		//}
		pageUtil.Ajaxcall(action,params,requestType,CallBackFunction,false);
	},
	loginuser : function(){
		var name = $('#login_user_name').val();
		var pass = $('#login_user_pass').val();
		var action = "handle_ajax_call.php";
		var params = {};
		params.name = name;
		params.pass = pass;
		params.action = "loginUser";
		var requestType = "POST";
		var CallBackFunction = function(data){
			if(data !==undefined){
				
				var jsonobj = JSON.parse(data);
				if(jsonobj.resultId == 2)
				{
					var result = jsonobj.result;
					window.location.replace("profile_page.php");
					
				}
				else if(jsonobj.resultId == 1){
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.result+'</p>');
	
				}
				else if(jsonobj.resultId == 5){
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.mismatch+'</p>');
	
				}
			}
		}
		pageUtil.Ajaxcall(action,params,requestType,CallBackFunction,false);
	},
	userData : function(){
		var action = "handle_ajax_call.php";
		var params = {};
		params.action = "userData";
		var requestType = "POST";
		var CallBackFunction = function(data){
			if(data !==undefined){
				
				var jsonobj = JSON.parse(data);
				if(jsonobj.resultId == 1)
				{
					var name = jsonobj.name;
					var dob = jsonobj.dob;
					var phone = jsonobj.phone;
					$("#userName").empty();
					$("#DOB").empty();
					$("#phone").empty();
					$("#userName").append("Welcome <b>"+name+"</b>");
					$("#DOB").append("Date Of Birth : <b>"+dob+"</b>");
					$("#phone").append("Phone Number : <b>"+phone+"</b>");
				}
				else{
					alert("error");
				}
			}
		}
		pageUtil.Ajaxcall(action,params,requestType,CallBackFunction,false);

	},
	dataEdit : function(){
		var action = "handle_ajax_call.php";
		var params = {};
		params.action = "dataEdit";
		var requestType = "POST";
		var CallBackFunction = function(data){
			if(data !==undefined){
				
				var jsonobj = JSON.parse(data);
				if(jsonobj.resultId == 1)
				{
					var name = jsonobj.name;
					var dob = jsonobj.dob;
					var phone = jsonobj.phone;
		
		$("#editlist").empty();
		$("#editlist").append('<div style="padding-top:10px;"></div>');
	$("#editlist").append('<p>Date Of Birth</p> <input type="date" name="user_dob" id="user_dob" value ="'+dob+'">');
	$("#editlist").append('<p>Phone Number</p> <input type="number" name="user_phone" id="user_phone" value ="'+phone+'">');
						$("#editlist").append('<div style="padding-top:10px;" align="center"><button class="btn btn-success" id="dataUpdate" onClick="pageUtil.dataUpdate();">Update</button></div>');
					}

				else{
					alert("error");
				}
			}
		}
		pageUtil.Ajaxcall(action,params,requestType,CallBackFunction,false);

	},
	dataUpdate : function(){
		var newdob = $('#user_dob').val();
		var newphone = $('#user_phone').val();
		var action = "handle_ajax_call.php";
		var params = {};
		params.newdob =newdob;
		params.newphone =newphone;
		params.action = "dataUpdate";
		var requestType = "POST";
		var CallBackFunction = function(data){
			if(data !==undefined){
				var jsonobj = JSON.parse(data);
				if(jsonobj.resultId == 1)
				{
					pageUtil.userData();
					$("#editlist").empty();
					$("#error_message").empty();
					$("#error_message").append('<p style="color:green;">Profile Updated</p>');
			
				}
				else if(jsonobj.resultId == 7){
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.phone+'</p>');
				
				}
				else{
					alert("error");
				}
			}
		}
		pageUtil.Ajaxcall(action,params,requestType,CallBackFunction,false);

	},
	passEdit : function(){
		var action = "handle_ajax_call.php";
		var params = {};
		params.action = "passEdit";
		var requestType = "POST";
		var CallBackFunction = function(data){
			if(data !==undefined){
				
				var jsonobj = JSON.parse(data);
				if(jsonobj.resultId == 1)
				{
					var name = jsonobj.name;
					var dob = jsonobj.dob;
					var phone = jsonobj.phone;
	
		$("#editlist").empty();	
		$("#editlist").append('<div style="padding-top:10px;"></div>');
	$("#editlist").append('Old Password <input type="password" name="old_pass" id="old_pass">');
	$("#editlist").append('New Password <input type="password" name="new_pass" id="new_pass">');				
	
		$("#editlist").append('<div style="padding-top:10px;" align="center"><button class="btn btn-success" id="passUpdate" onClick="pageUtil.passUpdate();">Update Password</button></div>');
						
						}
				else{
					alert("error");
				}
			}
		}
		pageUtil.Ajaxcall(action,params,requestType,CallBackFunction,false);

	},
	passUpdate : function(){
		var oldpass = $('#old_pass').val();
		var newpass = $('#new_pass').val();
		var action = "handle_ajax_call.php";
		var params = {};
		params.oldpass =oldpass;
		params.newpass =newpass;
		params.action = "passUpdate";
		var requestType = "POST";
		var CallBackFunction = function(data){
			if(data !==undefined){

				var jsonobj = JSON.parse(data);
				if(jsonobj.resultId == 1)
				{
						$("#editlist").empty();
					$("#error_message").empty();
					$("#error_message").append('<p style="color:green;">Password Updated</p>');
			
				}
				else if(jsonobj.result == 5 ){
					$("#error_message").empty();
		$("#error_message").append('<p style="color:red;">'+jsonobj.mismatch+'</p>');
				}
				else{
					alert("error");
				}
			}
		}
		pageUtil.Ajaxcall(action,params,requestType,CallBackFunction,false);

	}


}