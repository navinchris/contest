<?php
	include('include_js.php');
	include('establish_session.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Guvi - Index Page For Login or Register</title>
</head>
<body>
	<div class="logo"></div>
		<div class="head">
			<h3>Home Page</h3>
		</div>
		 <div class="row">
    <div class="col-sm-12">
    	<div class="card">
	<div class="card-body">
		<p>Hi Sir/Madam</p>
		<p>Contact Number : +91 9578443709</p>
 <div class="row" align="center">
    <div class="col-sm-6" style="padding-bottom: 10px;">
	<a href="login.php"><button class="btn btn-primary" >Login</button></a>
</div>

    <div class="col-sm-6" >
	<a href="register.php"><button class="btn btn-primary" >Register</button></a>
</div>
</div>



</div>

</div>
	</div>
</div>

	<marquee behavior="scroll" direction="left" style="color: white">I am Navin, B.Tech Information Technology (II - Year). Kamaraj College of Engineering and Technology.</marquee>
</body>
</html>