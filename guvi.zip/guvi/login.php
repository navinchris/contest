<?php
	include('include_js.php');
	include('establish_session.php');
	include('redirect_profile_page.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Guvi - Login Page</title>
	
</head>
<body>
	
	<div class="container">
	<div class="logo"></div>
		<div class="head">
			<h3>LogIn</h3>
		</div>
		 <div class="row">
    <div class="col-sm-12">
    	<div class="card">
	<div class="card-body">
		<div id="error_message"></div>
		User Name*
	 <input class="" type="text" name="login_user_name" id="login_user_name">
	

	Password* <input class="" type="password" name="login_user_pass" id="login_user_pass">
	<div align="center" class="login"><button class="btn btn-success" name="login_user_submit" id="login_user_submit" type="button" onClick="pageUtil.loginuser();">Submit</button>
	</div>
	</div>
	
	<div align="right"class="bottom"><a href="register.php"><p class="bottomlink">Create Account</p></a></div>
	</div>

</div>
	</div>
</body>
</html>