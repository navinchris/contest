<?php
include('establish_db_connection.php');

$user_list = "CREATE TABLE `user_list` ( `USER_ID` bigint(20) NOT NULL AUTO_INCREMENT, `USER_NAME` varchar(30) NOT NULL,`USER_PASS` varchar(150) NOT NULL, `USER_DOB` date NOT NULL, `USER_PHONE` bigint(20) NOT NULL, PRIMARY KEY (`USER_ID`) ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1";

if (mysqli_query($con, $user_list)) 
{
    echo "table created successfully";
} 
else 
{
    echo "error creating users table";
}
include('destroy_db_connection.php');

?>