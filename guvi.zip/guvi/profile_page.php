<?php 
	
	include('establish_session.php');
	include('include_js.php');
	include('check_Login.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Guvi - Profile Page</title>
	<script type="text/javascript">
		$(document).ready(function(){
			pageUtil.userData();
		})
	</script>
</head>
<body>
	<div class="container">
	<div class="logo"></div>
		<div class="head">

			<h5 id="userName">Welcome : NULL </h5>
		</div>
		 <div class="row">
    <div class="col-sm-12">
    	<div class="card">
	<div class="card-body">
		<div id="error_message"></div>
	<p id="DOB"> Date Of Birth: NULL</p>
	<p id="phone"> Phone Number: NULL</p>
	 <div class="row" align="center">
    <div class="col-sm-6" style="padding-bottom: 10px;">
	<button class="btn btn-primary" id="edit" onclick="pageUtil.dataEdit();">Edit Profile</button>
</div>

    <div class="col-sm-6" >
	<button class="btn btn-primary" id="edit" onclick="pageUtil.passEdit();">Edit Password</button>
</div>
</div>
<div >
	<p id="editlist"></p>
</div>
</div>
<div align="right"class="bottom"><a href="destroy_session.php"><p class="bottomlink">Log Out</p></a></div>
	</div>
	</div>

</div>
	</div>
</body>
</html>