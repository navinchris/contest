<?php
if($_SESSION['logedIn'] == false)
{
	session_destroy();
	header('Location: login.php');	
}
?>