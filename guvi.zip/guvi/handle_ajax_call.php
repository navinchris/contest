<?php
	include('establish_db_connection.php');
	$actionType = $_POST['action'];
	if(isset($_POST['name']) && isset($_POST['pass'])){
	$name = $_POST['name'];	
	$pass = md5($_POST['pass']);	
	}
	if(isset($_POST['cnfpass']) && isset($_POST['dob']) && isset($_POST['phone'])){
	$cnfpass = md5($_POST['cnfpass']);
	$dob = $_POST['dob'];	
	$phone = $_POST['phone'];	
	}
	$result = new stdClass();
	if(!empty($actionType) && $actionType === "registerUser"){
		if(empty($name) || empty($pass) || empty($cnfpass) || empty($dob) || empty($phone)){
			$result->resultId = "1";
			$result->result = "Mandatory Fields Required";
		}
		else if($pass !== $cnfpass){
			$result->resultId="6";
			$result->password="Password Mis Match";
		}
		else if(strlen($phone)!=10 ){
			$result->resultId="7";
			$result->phone="Wrong Phone Number Format";
		}
		else{
			$queryUser = "SELECT * FROM $userlist WHERE USER_NAME = '$name'";
			$query = "INSERT INTO $userlist (USER_NAME,USER_PASS,USER_DOB,USER_PHONE) VALUES ('$name','$pass','$dob',$phone)";
			try{
				$dbResultCheck = mysqli_query($con,$queryUser);
				if($dbResultCheck && mysqli_num_rows($dbResultCheck)>=1){
					$result->resultId = "2";
					$result->result = "Email Address Already Exists";
				}
				else{
					$dbResult = mysqli_query($con,$query);
					if($dbResult){
						$queryFetch = "SELECT * FROM $userlist WHERE USER_NAME = '$name' ";
					$dbResultGET = mysqli_query($con,$queryFetch);
					$row = mysqli_fetch_row($dbResultGET);
						$_SESSION['logedIn'] = true;
						$_SESSION['userId'] = $row[0];
						$result->resultId="3";
						$result->name=$row[1];
						$result->result ="welcome";
					}
					else{
						$result->resultId="4";
						$result->result = "Error occure in register";
					}

				}
			}
			catch(Exception $e){
				$result->resultId="5";
				$result->result = "Exception occured - Action Type (".$actionType.":".$e->getMessage();
			}

		}

	}
	else if(!empty($actionType) && $actionType == "loginUser"){
		if(empty($name) || empty($pass)){
			$result->resultId = "1";
			$result->result = "Mandatory Fields Required";
		}
		else{
			try{
				$querycheck = "SELECT * FROM $userlist WHERE USER_NAME = '$name'";
			$dbResultGET = mysqli_query($con,$querycheck);
			if($dbResultGET){
				$row = mysqli_fetch_row($dbResultGET);
				if($row[2] == $pass){
				$result->resultId = "2";
			$_SESSION['logedIn'] = true;
			$_SESSION['userId'] = $row[0];
			$result->result = $row[1];
			}
			else{
				$result->resultId = "5";
			$result->mismatch = "Error in UserName / Password";
			}
			}
			else{
				$result->resultId = "3";
			$result->result = "Error in Login";
			}
		}
		catch(Exception $e){
			$result->resultId="4";
				$result->result = "Exception occured - Action Type (".$actionType.":".$e->getMessage();
		}
	}
	}
	else if(!empty($actionType) && $actionType == "userData"){
		try{
			$userId = $_SESSION['userId'];
			$querycheck = "SELECT * FROM $userlist WHERE USER_ID = '$userId'";
			$dbResultGET = mysqli_query($con,$querycheck);
			if($dbResultGET){
				$row = mysqli_fetch_row($dbResultGET);
				$result->resultId="1";
				$result->name=$row[1];
				$result->dob =$row[3];
				$result->phone=$row[4];
			}

		}
		catch(Exception $e){
			$result->resultId="4";
			$result->result = "Exception occured - Action Type (".$actionType.":".$e->getMessage();
			
		}
	}
	else if(!empty($actionType) && $actionType == "dataEdit"){
		try{
			$userId = $_SESSION['userId'];
			$querycheck = "SELECT * FROM $userlist WHERE USER_ID = '$userId'";
			$dbResultGET = mysqli_query($con,$querycheck);
			if($dbResultGET){
				$row = mysqli_fetch_row($dbResultGET);
				$result->resultId="1";
				$result->name=$row[1];
				$result->dob =$row[3];
				$result->phone=$row[4];
			}

		}
		catch(Exception $e){
			$result->resultId="4";
			$result->result = "Exception occured - Action Type (".$actionType.":".$e->getMessage();
			
		}
	}
	else if(!empty($actionType) && $actionType == "dataUpdate"){
			$userId = $_SESSION['userId'];
			$newDate = $_POST['newdob'];	
			$newPhone = $_POST['newphone'];
			if(strlen($newPhone)!=10 ){
			$result->resultId="7";
			$result->phone="Wrong Phone Number Format";
		}
		else{
			try{
				$querycheck = "UPDATE $userlist SET USER_DOB= '$newDate', USER_PHONE='$newPhone' WHERE USER_ID=$userId";
			$dbResults = mysqli_query($con, $querycheck);
				$result->resultId = "1";
			}
			
		catch(Exception $e){
			$result->resultId="4";
				$result->result = "Exception occured - Action Type (".$actionType.":".$e->getMessage();
		}
		}
	}
	else if(!empty($actionType) && $actionType == "passEdit"){
		try{
			$userId = $_SESSION['userId'];
			$querycheck = "SELECT * FROM $userlist WHERE USER_ID = '$userId'";
			$dbResultGET = mysqli_query($con,$querycheck);
			if($dbResultGET){
				$row = mysqli_fetch_row($dbResultGET);
				$result->resultId="1";
				$result->name=$row[1];
				$result->dob =$row[3];
				$result->phone=$row[4];
			}

		}
		catch(Exception $e){
			$result->resultId="4";
			$result->result = "Exception occured - Action Type (".$actionType.":".$e->getMessage();
			
		}
	}
	else if(!empty($actionType) && $actionType == "passUpdate"){
			$userId = $_SESSION['userId'];
			$oldPass = md5($_POST['oldpass']);	
			$newPass = md5($_POST['newpass']);
			try{
				$querycheck = "SELECT * FROM $userlist WHERE USER_ID = '$userId'";
			$dbResultGET = mysqli_query($con,$querycheck);
			if($dbResultGET){
				$row = mysqli_fetch_row($dbResultGET);
				$result->pass=$row[2];
				if($row[2] == $oldPass){
				$querycheck = "UPDATE $userlist SET USER_PASS='$newPass' WHERE USER_ID=$userId";
			$dbResults = mysqli_query($con, $querycheck);
				$result->resultId = "1";
					}
					else{
						$result->result="5";
						$result->mismatch ="Mis Match in Old Password";
					}
			}
			}
			
		catch(Exception $e){
			$result->resultId="4";
				$result->result = "Exception occured - Action Type (".$actionType.":".$e->getMessage();
		}
	}
	include('destroy_db_connection.php');
	echo json_encode($result);	
?>