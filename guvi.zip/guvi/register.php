<?php
	include('include_js.php');
	include('establish_session.php');
	include('redirect_profile_page.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Guvi - Register Page</title>
</head>
<body>
	<div class="container">
	<div class="logo"></div>
		<div class="head">
			<h3>Register</h3>
		</div>
		 <div class="row">
    <div class="col-sm-12">
    	<div class="card">
	<div class="card-body">
		<div id="error_message"></div>
	User Name*<input type="name" name="reg_user_name" id="reg_user_name">
	Password*<input type="password" name="reg_user_pass" id="reg_user_pass">
	Confirm Password*<input type="password" name="reg_user_cnfpass" id="reg_user_cnfpass">
	Date of Birth*<input type="date" name="reg_user_dob" id="reg_user_dob">
	Phone Number*<input type="number" name="reg_user_phone" id="reg_user_phone">
	<div align="center" class="login"><button class="btn btn-success" name="reg_user_submit" type="button" id="reg_user_submit" onClick="pageUtil.registeruser();">submit</button>
	</div>
</div>
	
	<div align="right"class="bottom"><a href="login.php"><p class="bottomlink">Already Member?</p></a></div>
	</div>

</div>
	</div>
</body>
</html>