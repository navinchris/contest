<?php
	include('establish_session.php');
	$servername = '127.0.0.1';
	$username = 'root';
	$password = '';
	$dbname = 'guvi';
	$userlist = 'user_list'; 
	$con = mysqli_connect($servername,$username,$password,$dbname);
	if(!$con){
		alert("Error in DB Connection");
	}
?>