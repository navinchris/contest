<?php
	if(isset($_SESSION['logedIn'])){
	if ($_SESSION['logedIn']== true){
		header('location:profile_page.php');
	}
	}
?>